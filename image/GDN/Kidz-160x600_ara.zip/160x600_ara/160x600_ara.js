(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"160x600_ara_atlas_", frames: [[0,0,160,600]]}
];


// symbols:



(lib._160x600_img = function() {
	this.initialize(ss["160x600_ara_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.terms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgHAUIAAgFIAFAAQADAAABgCQABgBAAgGIAAgPIAEAAIAAARQABAMgJAAgAADgNIAAgGIAEAAIAAAGgAgEgNIAAgGIAEAAIAAAGg");
	this.shape.setTransform(-143.8,224.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeAVIAAgEIAMAAIAAglIAFAAIgBAdQAHgRAOAAQAPAAAAAWIAAADIAJAAIAAAEgAgGACQgFAHgDAIIAfAAIABgFQAAgPgMAAQgGAAgGAFg");
	this.shape_1.setTransform(-147.6,224.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAAAUIAAgGIAEAAIAAAGgAgKAKIAAgEIAEAAQAEAAABgDIABgFIAAgRIAEAAIAAATIgBAGIAIAAIAAAEg");
	this.shape_2.setTransform(-151.475,225.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEACIgBgDIABgBIABADQAAABABAAQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAgBIAAAAIAAgCIABgBIAAADQAAAAAAABQAAAAAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAAAIgBgEIACAAIABAEIAAABQAAABAAAAQAAABgBAAQAAAAAAAAQgBABgBAAQAAAAAAgBQgBAAAAAAQgBgBAAAAQAAgBAAgBQAAAFgDAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAgBg");
	this.shape_3.setTransform(-151.5,221.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgSATQgFgGAAgJIAAgLIAEAAIAAAKQAAAIAFAFQAEAFAHAAQAJAAAEgGIgGAAQgFAAgDgFQgEgEAAgGQAAgGAEgEQAEgEAFAAQALAAAAANIAAALIAJAAIAAAFIgKAAQgFAKgMAAQgJAAgHgGgAgBgHQgCADAAAEQAAAEACADQABADAEAAIAIAAIAAgNQgBgHgGAAQgEAAgCADgAAGgTIAAgFIAEAAIAAAFgAgCgTIAAgFIAEAAIAAAFg");
	this.shape_4.setTransform(-154.95,224.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgBAVIAAgpIADAAIAAApg");
	this.shape_5.setTransform(-159.325,224.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgHAVIAAgEIAEAAQADAAACgDIABgGIAAgcIAFAAIAAAeQAAALgJAAg");
	this.shape_6.setTransform(-161.2,224.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgeAXIAAgEIAGAAQAHAAAAgIIAAgQIAFAAIAAARQAAADgBAEIAAAAIAIAAQAFAAAAgJIAAgPIAFAAIAAARQAAAEgCADIAIAAQAGAAAAgJIAAgPIAFAAIAAARQAAAEgCADIALAAIAAAEgAAEgKIAAgFIAEAAIAAAFgAgDgKIAAgFIADAAIAAAFgAAAgRIAAgFIAFAAIAAAFg");
	this.shape_7.setTransform(-164.95,224);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgLAQQAJAAAAgLIAAgYIAEAAIAAAYIAKAAIAAAFIgLAAQgBAKgLAAg");
	this.shape_8.setTransform(-169.075,225.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAAAQQAHAAABgLQgCAEgGAAQgEAAgEgEQgEgEAAgGQAAgGAEgEQAEgEAEAAQAGAAADAEQAEAEgBAGIAAAJQABAQgNAAgAgHgFQAAAEACACQACADADAAQAIAAAAgJQAAgKgIAAQgHAAAAAKg");
	this.shape_9.setTransform(-172,225.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgWAVIAAgEIAFAAIAAglIAFAAIgBAdQAHgRANAAQAQAAAAAWIAAAHgAgEACQgHAGgCAJIAfAAIAAgFQAAgPgLAAQgGAAgFAFg");
	this.shape_10.setTransform(-176.225,224.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgBAQQAJAAAAgLQgDAEgFAAQgEAAgEgEQgDgEAAgGQAAgGADgEQAEgEAEAAQAFAAAEAEQADAEAAAGIAAAJQAAAQgNAAgAgHgFQAAAJAHAAQAIAAAAgJQAAgKgIAAQgHAAAAAKg");
	this.shape_11.setTransform(-181.425,225.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgBAVIAAgpIADAAIAAApg");
	this.shape_12.setTransform(-183.675,224.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgMAaIAAgEIALAAIgIggIAEAAIAHAgIACAAQAHAAAAgJIAAgcIAFAAIAAAeQAAALgKAAgAgPgPIAAgCIADAAIAAgDQAAgFAFAAQAEAAABAEIgDAAQAAgBAAAAQAAgBAAAAQAAAAgBAAQAAAAgBAAQgBAAAAAAQgBAAAAABQAAAAAAABQAAAAAAABIAAADIAHAAIAAACg");
	this.shape_13.setTransform(-186.3,223.725);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgWAOIAAgEIAnAAIAAgDQAAgQgQAAQgHAAgEAGIgEgDQAGgIAJAAQAKAAAGAHQAGAGAAAIIAAAHg");
	this.shape_14.setTransform(-190.575,224.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgaAVIAAgEIAnAAIAAgDQAAgIgEgEQgEgEgHAAIgOAAIAKgSIAGAAIgIANIAGAAQAIAAAGAGQAGAGAAAJIAAADIAJAAIAAAEg");
	this.shape_15.setTransform(-195.275,224.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AACAVQgCAAgDgCQgDgDAAgFIAAgfIAFAAIAAAcQAAAFABABQAAABAAAAQAAABABAAQAAAAABAAQAAAAABAAIAEABIAAAEg");
	this.shape_16.setTransform(-198.3,224.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgWAUIAAgVQAAgSAOAAIASAAQAGAAAEAEQADAEAAAHQAAAFgDAEQgEAEgGAAQgNAAAAgNQAAgGADgFIgIAAQgKAAAAAOIAAAVgAACgEQAAAJAIAAQAIAAAAgKQAAgKgIAAQgIAAAAALg");
	this.shape_17.setTransform(-202.225,225.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.terms, new cjs.Rectangle(-204.5,221.1,61.5,6.300000000000011), null);


(lib.red = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DA001D").s().p("EgMpAu4MAAAhdvIZTAAMAAABdvg");
	this.shape.setTransform(81,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.red, new cjs.Rectangle(0,0,162,600), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAAAgQAPgBAAgSQgEAIgLAAQgNAAgIgJQgJgKAAgNQAAgPAJgJQAIgJANAAQAOAAAJAKQAIAJAAAOIAAAeQAAAagfAAgAgKgYQgEAFAAAIQAAAHAEAFQAFAFAFAAQAGAAAFgFQADgEAAgHQAAgJgDgFQgFgFgGAAQgGAAgEAFg");
	this.shape.setTransform(93.15,24.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgRAfQATAAAAgVIAAg2IAQAAIAAA0QAAAlgjAAg");
	this.shape_1.setTransform(86.9,24.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag8AhIAAgRIAMAAQAMAAAAgQIAAggIAQAAIAAAgQAAALgCAEIAAABIAPAAQALAAAAgQIAAggIAQAAIAAAgQAAANgDADIAQAAQAMAAAAgQIAAggIAQAAIAAAfQAAAPgIAJQgHAKgNAAg");
	this.shape_2.setTransform(77.825,23.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AACAvQgKgBgHgHQgFgHAAgMIAAhBIAQAAIAAA7QAAALAEADQADACAJAAIAJAAIAAARg");
	this.shape_3.setTransform(70.075,22.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgTAxIAAgQIANAAQAGAAADgFQAAgCAAgIIAAgZIARAAIAAAeQAAAagYAAgAgPgPIAAgKIAIAAIgBgHQgBgHAFgFQAEgEAGAAQAJAAAEAJIgHAEQgCgEgEAAQgGAAAAAIIACAGIASAAIAAAKg");
	this.shape_4.setTransform(64.45,21.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgrAsQgNgPAAgUIAAgNIAQAAIAAAMQAAAOAIALQAIAKANAAQAMAAAIgKQAIgLAAgOIAAhBIARAAIAABCIgBAJIAYAAIAAARIgeAAQgNAYgZAAQgSAAgOgPg");
	this.shape_5.setTransform(57.275,23.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgUAvIAAgQIAOAAQAHAAACgFQABgCAAgIIAAghIARAAIAAAmQAAAagYAAgAAFgeIAAgQIAPAAIAAAQg");
	this.shape_6.setTransform(45.075,22.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhGAhIAAgRIAQAAQAMAAAAgQIAAgZIAQAAIAAAUQAUgbAXAAQAlAAAAAwIARAAIAAARgAgHgIQgMAJgGAPIA/AAIAAgEQAAgNgGgIQgGgJgKAAQgMAAgLAKg");
	this.shape_7.setTransform(36.275,23.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgFAxIAAgRIAPAAIAAARgAggAxIAAgRIAQAAIAAARgAggARIAAgQIAQAAQAGgBAEgEQABgDAAgHIAAgiIAPAAIAAAhQAAANgEADIAbAAIAAAQg");
	this.shape_8.setTransform(26.55,25.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAdA2QgKAAgHgHQgHgFgDgKQgGALgLAAQgNAAgJgJQgIgKAAgPQAAgPAIgKQAIgJAOAAIAjAAIAAAtQAAARAQAAIAKAAIAAARgAgYgHQgFAHAAAJQAAAIAFAHQAEAFAHAAQAIAAAEgGQAEgGAAgJIAAgVIgOAAQgIABgFAFgAACgkIAAgRIAQAAIAAARgAgYgkIAAgRIAQAAIAAARg");
	this.shape_9.setTransform(19.125,21.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgPAtQgHgEgEgIQgEgHgCgIIgBgSIABgQQACgJAEgHQAEgIAHgEQAHgEAIgBQAKABAGAEQAHAEAEAIQAEAHACAJIABAQIgBASQgCAIgEAHQgEAIgHAEQgGAEgKAAQgIAAgHgEgAgGgeQgEAFgBACIgDALIgBAMIABAMIADALQABAEAEAEQAEACACAAQAEAAADgCQADgDACgFIADgLIABgMIgBgMIgDgLIgFgHQgDgCgEAAQgCAAgEACg");
	this.shape_10.setTransform(107.575,5.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMAwIgIgCIgGgDIgGgDIAIgQQAFAEAFACQAGACAGABIAGgBQAEgCACgCQACgBABgDQACgDAAgFQAAgJgFgEQgGgDgJAAIgSABIAAgxIA1AAIAAARIgkAAIAAAPIABAAIACAAQARAAAJAIQAKAIgBAQQABAJgDAGQgDAGgFAEQgFAFgGABQgGACgHAAg");
	this.shape_11.setTransform(100,6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgdAxIABgSIABgGIAEgGIAFgGIATgOIAFgEIAEgEIABgEIABgFQAAgGgEgDQgDgDgGAAIgIABIgGADIgEAEIgDACIgJgNIAEgEIAGgEIAKgFQAGgBAGgBQAHAAAFACQAGADADADQAEAEADAFQACAFAAAHQAAAKgEAGQgEAGgHAEIgXATIgCADIgBADIAqAAIAAARg");
	this.shape_12.setTransform(92.675,5.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AghAhIAAgRIAzAAQAAgagVgGIgPgBIAAgPIAQABQADAAAEACQAdAJAAAkIAAARg");
	this.shape_13.setTransform(82.5,7.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgpAwIAAgRIAXAAQgEgIAAgJQAAgOAJgJQAJgKANAAQAOAAAKALQAJAIAAAOQAAAPgJAJQgJAKgPAAgAgBABQgFAEAAAJQAAAIAFAFQADAGAIgBQAGAAAFgEQAEgGAAgIQAAgIgFgFQgEgEgHgBQgHAAgDAFgAAPgfIAAgQIAQAAIAAAQgAgLgfIAAgQIAOAAIAAAQg");
	this.shape_14.setTransform(73.575,5.95);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgFAxIAAgRIAPAAIAAARgAggAxIAAgRIAQAAIAAARgAggARIAAgQIAQAAQAHgBADgDQABgFAAgGIAAgiIAQAAIAAAhQAAAMgFAEIAbAAIAAAQg");
	this.shape_15.setTransform(66.35,9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAhA1QgVAAgLgIQgKAIgVAAIgSAAIAAgRIARAAQALAAADgBQgHgFgEgJQgDgGAAgIQAAgGABgDQAJgXAWAAQANAAAKAIQALAJAAAOQAAAHgEAIQgDAJgHAFQACABALAAIAPAAIAAARgAgMgGQgEAEAAAHQAAALAJAIIAIAFIAJgFQAJgHAAgMQAAgHgEgEQgFgGgJAAQgJAAgEAGgAAGgkIAAgQIAQAAIAAAQgAgUgkIAAgQIAQAAIAAAQg");
	this.shape_16.setTransform(58.725,5.425);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAdA2QgKAAgHgHQgHgFgCgKQgHALgLAAQgNAAgJgJQgIgKAAgPQAAgPAIgKQAIgJAOAAIAjAAIAAAtQgBARARAAIAKAAIAAARgAgYgHQgFAHAAAJQAAAIAFAHQAEAFAHAAQAHAAAGgGQADgGAAgJIAAgVIgOAAQgIABgFAFgAADgkIAAgRIAPAAIAAARgAgYgkIAAgRIAQAAIAAARg");
	this.shape_17.setTransform(49.7,5.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgPAVIgaAAIAAgRIAUAAIAAgBIAAgDQAAgOAJgJQAIgKAOABQAOAAAJAJQAJAJAAAOQAAAOgJAKQgJAJgOAAQgQAAgJgMgAAAgNQgFAFAAAIQAAAHAFAGQAEAGAGAAQAIgBADgFQAFgEAAgJQgBgIgEgFQgEgFgIAAQgGAAgDAFg");
	this.shape_18.setTransform(36.5,8.65);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("Ag5AhIAAgRIBTAAQAAgNgIgJQgJgLgPAAQgFAAgHADQgIADgFAGIgHgMQAHgHAHgEQALgEAIAAQAOAAAMAHQAUANACAcIAPAAIAAARg");
	this.shape_19.setTransform(26.95,7.425);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AggAvIAAgRIAPAAQAHAAACgFQACgDABgIIAAg7IAOAAIAAA6QABANgEAEIAbAAIAAARg");
	this.shape_20.setTransform(18.25,6.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgGAxIAAgRIAQAAIAAARgAghAxIAAgRIAQAAIAAARgAggARIAAgQIAQAAQAGgBADgDQACgEAAgHIAAgiIAPAAIAAAhQAAANgDADIAbAAIAAAQg");
	this.shape_21.setTransform(12,9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAcA2QgJAAgHgHQgHgFgDgKQgGALgLAAQgOAAgIgJQgIgJAAgQQAAgPAIgKQAIgJAOAAIAiAAIAAAtQAAARARAAIAKAAIAAARgAgdAJQAAAIAEAHQAFAFAHAAQAHAAAFgGQAEgGAAgJIAAgVIgOAAQgSABAAAVgAACgkIAAgRIAQAAIAAARgAgYgkIAAgRIAQAAIAAARg");
	this.shape_22.setTransform(4.575,5.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,111,30.1), null);


(lib.Path_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").p("AANjHIBHAAQANAAAKAJQAJAJAAANIAAFQQAAANgJAJQgKAKgNAAIinAAQgNAAgJgKQgKgJAAgNIAAkr");
	this.shape.setTransform(12.075,20.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(-0.5,-0.5,25.2,43.9), null);


(lib.Path_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").p("AAAABIAOgdQAQgdAbgdQA1g7AyAAQA7AAAkArQAkApAAA9QAAA+gkApQgkArg7AAQg1AAg0g6Igqg7IgNgcIgQgeQgNgdgZgdQgxg6g4AAQg7AAglArQgjApAAA9QAAA+AjApQAlArA7AAQA5AAAyg6QAYgeAOgdg");
	this.shape.setTransform(29.6,15.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_0, new cjs.Rectangle(-0.5,-0.5,60.2,31.1), null);


(lib.Group_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAVIgaAAIAAgRIAUAAIAAgBIgBgDQAAgOAJgJQAKgKANAAQAOAAAJAKQAJAKAAAOQAAAOgJAJQgJAKgOgBQgQAAgJgMgAgBgNQgEAGAAAHQAAAIAEAFQAEAFAHABQAHAAAEgGQAEgFAAgHQAAgIgEgFQgFgGgHABQgGAAgEAEg");
	this.shape.setTransform(45.775,23.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AggAwIAAgRIAPAAQAHAAADgFQACgDgBgIIAAggIAPAAIAAAgQAAAMgDAEIAcAAIAAARgAgGgeIAAgRIAPAAIAAARgAghgeIAAgRIAQAAIAAARg");
	this.shape_1.setTransform(38.65,20.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAgQALAAAEgLIgPAAQgMAAgKgKQgJgKAAgNQAAgOAKgIQAIgKAOABQAMgBAJAKQAIAIAAAPIAAAPIAUAAIAAARIgTAAQgFAXgaABgAgTgYQgEAFgBAGQAAAIAFAFQAFAEAGAAIANAAIAAgTQgBgOgMAAQgHAAgEAFg");
	this.shape_2.setTransform(31.65,23.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgHAvIAAhdIAPAAIAABdg");
	this.shape_3.setTransform(25.4,21.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag8AhIAAgRIAMAAQAMABAAgRIAAgYIARAAIAAATQATgbAYAAQAlAAAAAyIgBAPgAgBgIQgLAJgHAPIA/AAIAAgEQAAgNgGgIQgGgJgKAAQgMABgLAJg");
	this.shape_4.setTransform(16.925,22.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgrAsQgNgOAAgVIAAgNIAQAAIAAALQAAAQAIAJQAJALANAAQALAAAJgLQAIgJAAgQIAAhBIAQAAIgBBMIAYAAIAAARIgeAAQgGAKgKAHQgLAGgKAAQgTAAgOgOg");
	this.shape_5.setTransform(5.725,22.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgHAvIAAhdIAPAAIAABdg");
	this.shape_6.setTransform(43.25,4.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgUAwIAAgRIAOAAQAHAAACgFIABgKIAAghIARAAIAAAnQgBAagXAAgAAEgeIAAgRIARAAIAAARg");
	this.shape_7.setTransform(38.9,4.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AggAwIAAgRIAPAAQAIAAACgFQACgDAAgIIAAggIAPAAIAAAgQAAAMgEAEIAcAAIAAARgAgFgeIAAgRIAPAAIAAARgAghgeIAAgRIAQAAIAAARg");
	this.shape_8.setTransform(33.925,4.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgdAfQATAAAAgVIAAg2IAQAAIAAAwIAZAAIAAARIgaAAQgEAYgeAAg");
	this.shape_9.setTransform(28.15,7.425);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgUAwIAAgRIAOAAQAHAAACgFQABgBAAgJIAAghIARAAIAAAnQAAAagYAAgAAFgeIAAgRIAPAAIAAARg");
	this.shape_10.setTransform(21.975,4.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgZApQguAAAAgpIAAgYIAQAAIAAAYQAAAOAIAGQAHAEANAAIAwAAQAIAAABgFQACgEAAgHIAAggIARAAIAAAgQgBAMgDAEIAbAAIAAARgAgFgYIAAgQIAPAAIAAAQgAgggYIAAgQIAQAAIAAAQg");
	this.shape_11.setTransform(13.15,5.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(0,0,50,28.1), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgQBNIAAiZIAhAAIAACZg");
	this.shape_23.setTransform(102.225,126.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AglBMIAAggIAZAAQAQABAAgXIAAhiIAiAAIAABrQAAARgLAOQgMAOgUAAg");
	this.shape_24.setTransform(94.4,126.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgXBLIAAgcIAcAAIAAAcgAhiAjIAAggICFAAQAAgRgNgOQgOgPgWAAQgKAAgLAFQgLAFgHAHIgRgXQAYgZAjAAQAUAAAQAIQAmASAGAzIAeAAIAAAgg");
	this.shape_25.setTransform(82.275,130.575);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AhMA2IAAggIBVAAQAAgYgNgMQgPgLgfAAIAAgcQAfAAANAFQAxARAAA1IAiAAIAAAgg");
	this.shape_26.setTransform(65.4,128.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAGBKIAAgcIAeAAIAAAcgAglBKIAAgcIAdAAIAAAcgAggAiIAAggIAVAAQAQAAAAgWIAAg0IAhAAIAAA9QAAASgKANQgMAOgUAAg");
	this.shape_27.setTransform(51.625,130.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AhMA2IAAggIBVAAQAAgYgNgMQgOgLggAAIAAgcQAfAAAOAFQAvARAAA1IAjAAIAAAgg");
	this.shape_28.setTransform(41.3,128.725);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgpBBQgQgPAAgbQAAgZAQgPQAPgQAaAAQAaAAAPAPQARAPAAAZQAAAbgQAQQgPAPgbAAQgZAAgQgPgAgaAYQAAANAHAJQAHAIAMABQANgBAGgIQAHgJAAgNQAAgggaAAQgaAAAAAggAAHgzIAAgcIAeAAIAAAcgAglgzIAAgcIAeAAIAAAcg");
	this.shape_29.setTransform(25.575,126.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AglBBIAAh+IAeAAIABANIAGgFIAGgFIAJgEQAEgBAGAAIAIAAIAFACIgEAbIgLAAQgIAAgIAEIgMALIAABUg");
	this.shape_30.setTransform(101.1,97.95);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgSA+QgLgDgJgJQgIgIgFgNQgFgNAAgQQAAgOAEgNQAGgOAHgHQAIgIALgFQAKgEALAAQAMAAALAEQAKAEAHAIQAHAIAFANQAEAPAAAPIAAAGIhRAAQACARAIAGQAKAHAMAAIANgBIAKgDIAMgHIAJAbIgGADIgKAEIgOAEIgSABQgKAAgMgEgAgOghQgHAGgCANIAvAAQAAgGgCgFQgCgFgEgDIgHgFIgIgBQgIAAgHAGg");
	this.shape_31.setTransform(89.175,98.075);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgmBBIAAh+IAeAAIACANIAGgFIAGgFIAJgEQAEgBAFAAIAJAAIAGACIgFAbIgLAAQgIAAgJAEIgLALIAABUg");
	this.shape_32.setTransform(78.925,97.95);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgaA8QgKgFgJgKQgHgJgDgMQgFgNAAgLQAAgLAFgNQADgMAHgJQAIgIALgHQAMgFAOAAQAPAAALAFQAMAHAHAIQAJALADAKQADALABANQgBANgDALQgDALgJAKQgJALgKAEQgLAGgPAAQgOAAgMgGgAgLgjQgGADgDAFQgEAGgCAGQgBAHAAAIQAAAIABAHQABAFAFAHQADAFAGADQAFADAGAAQAHAAAFgDQAGgDADgFIAGgMQACgIgBgHIgBgPIgGgMQgDgFgGgDQgFgDgHAAQgFAAgGADg");
	this.shape_33.setTransform(66.65,98.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgIBXQgGgCgFgEQgEgEgDgGQgDgHAAgJIAAiPIAgAAIAACJQAAAGADADQACADAFAAIAGgBIAFgCIAGAZIgKAEQgIACgIAAQgHAAgFgCg");
	this.shape_34.setTransform(56.825,95.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("Ag3BZIAAivIAeAAIABAKIAMgIQAIgFAIAAQANABAKAFQAJAFAIAJQAGALADALQAEAKgBAOQAAAMgDAMQgFANgHAIQgIAKgMAFQgMAGgPAAQgIAAgJgEIAAAygAgOg5QgGADgDAFIAAA8QAHAEAIAAQAIAAAGgEQAGgDAFgFQAEgEABgHQADgGAAgIIgCgOIgFgNQgFgGgEgDQgEgDgGAAQgIAAgFAEg");
	this.shape_35.setTransform(45.85,100.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAbA/IgbgoIgcAoIgiAAIAtg+Igug/IAlAAIAaAnIAcgnIAhAAIgrA+IAtA/g");
	this.shape_36.setTransform(32.3,98.075);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Ag7BYIAAiuIBxAAIAAAfIhPAAIAAApIBBAAIAAAeIhBAAIAAAoIBVAAIAAAgg");
	this.shape_37.setTransform(18.725,95.65);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgbAhIgrAAIAAggIAhAAQAAgYAOgPQAOgPAZAAQAZAAAPAPQAPAOAAAYQAAAYgPAPQgPAPgYAAQgeAAgOgVgAAAgTQgFAIAAALQAAAMAFAHQAGAIALAAQAJAAAGgHQAGgIAAgLQAAgbgVgBIgCAAQgJAAgGAIg");
	this.shape_38.setTransform(97.075,71.35);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgTBgQggAAgSgPQgRgQAAgbQAAgUAKgOQAKgOATgGQgFgLAAgOQAAgXAOgPQAPgQAWAAQAfAAANAdIgbAMQgEgOgNAAQgJAAgGAHQgFAHAAALQAAATANAFIA0AAQAAAsApAAIACAAIAAAgIgCAAQg0AAgPgtIgmAAQgSAAgIAGQgIAGAAAOQAAAaAiAAIAsAAIAAAgg");
	this.shape_39.setTransform(81.975,69.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AAEBKIAAgcIAeAAIAAAcgAgiAiIAAggIAUAAQAQAAAAgWIAAg0IAiAAIAAA9QAAASgLANQgLAOgVAAg");
	this.shape_40.setTransform(63.3,71.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAEBMQgSAAgKgKQgLgKAAgSIAAhyIAhAAIAABgQAAANAEAGQAGAFASAAIAKAAIAAAgg");
	this.shape_41.setTransform(56.675,67.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AhFBMIAAggIAiAAQgEgIAAgOQAAgYAPgOQAOgOAYAAQAZAAAPAOQAQANAAAZQAAAZgPAOQgOAPgaAAgAgBAEQgFAJAAAJQAAALAFAIQAFAIALABQALAAAGgJQAFgGAAgMQAAgbgVAAIgDAAQgKAAgEAIgAAVgwIAAgcIAeAAIAAAcgAgXgwIAAgcIAdAAIAAAcg");
	this.shape_42.setTransform(43.675,67.05);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAsBaQgdAAgMgdQgIAOgYAAQgVAAgNgQQgNgQAAgZQAAgaANgQQANgPAXAAIA/gBIAABKQgBAYAZAAIARAAIAAAggAgkgFQgHAIAAAOQAAANAHAJQAGAJAKAAQALAAAFgJQAGgJgBgPIAAgeIgUAAQgLAAgGAKgAgFg+IAAgbIAdAAIAAAbgAgyg+IAAgbIAeAAIAAAbg");
	this.shape_43.setTransform(29.65,65.675);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgPBmIAAiYIAgAAIAACYgAgUhAIAAgMIAJAAIgBgGQAAgIAFgFQAFgGAHAAQALAAAFALIgLAFQgBgFgEAAQgFAAAAAHQAAAGADABIASAAIAAAMg");
	this.shape_44.setTransform(102.025,34.825);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AhoBMIAAggIAxAAIAAh4IAhAAIgDBNQAegfAjAAQAgAAARAXQAQAVAAApIgBAVgAgaAsIBgAAIAAgEQAAgTgIgLQgJgLgQgBQgkABgbAtg");
	this.shape_45.setTransform(87.425,37.35);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AA9BYQgjAAgZgJQgXAJgjAAIgWAAIAAggIAWAAQAQAAADgBQgPgTAAgUQAAgKADgIQAFgRAOgKQAPgKARAAQATAAAOAKQAOAKAGARQADAIAAAKQAAAUgQATQAFABAPAAIATAAIAAAggAgRgFQgGAHAAALQAAASAOAJIAKAIQAFgCAHgGQAOgJAAgSQAAgLgHgHQgHgIgMAAQgKAAgIAIgAgNg8IAAgbIAdAAIAAAbg");
	this.shape_46.setTransform(70.625,36.175);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AAFBMQgSAAgLgKQgLgKAAgSIAAhyIAiAAIAABgQAAANAEAGQAGAFARAAIAKAAIAAAgg");
	this.shape_47.setTransform(59.925,37.35);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgkBMIAAggIAYAAQAQABAAgXIAAhiIAhAAIAABrQAAASgKANQgMAPgUgBg");
	this.shape_48.setTransform(50.225,37.35);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgoBMQhPABAAhDIAAgoIAhAAIAAAoQAAASAKAJQAKAHAaAAIA9AAQATAAAGgEQAGgFAAgPIAAhgIAiAAIAABhQAAANgFAKIAnAAIAAAggAgwgHIAAgRIANAAIgCgJQAAgMAIgJQAHgHALAAQAQAAAHAQIgPAHQgBgHgHAAQgHAAgBALQAAAHAGACIAaAAIAAASg");
	this.shape_49.setTransform(35.45,37.35);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AhCA3IAAggIAmAAQgFgMAAgKQAAgXAPgQQAOgQAXAAQAQAAAMAIQAMAIAGAOIgbAMQgEgOgPAAQgKAAgGAIQgDAHAAALQAAASALAFIA4AAIAAAgg");
	this.shape_50.setTransform(97.5,9.775);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgyBGQAhgBAAgfIAAhXIAhAAIAABKIAjAAIAAAgIglAAQgIAng4AAgAgPhDIAAgcIAdAAIAAAcg");
	this.shape_51.setTransform(86.575,9.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AggBGQAggBAAgfIAAhXIAhAAIAABUQAAAggQAPQgQAOghAAgAABhDIAAgcIAeAAIAAAcg");
	this.shape_52.setTransform(76.225,9.6);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AhFBNIAAghIAiAAQgEgKAAgMQAAgXAOgPQAPgPAYAAQAZAAAPAPQAQAOAAAYQAAAZgPAOQgPAPgYABgAgBAEQgFAIAAAKQAAAMAFAHQAEAIAMAAQAKABAHgJQAEgGAAgMQAAgbgUAAIgDAAQgKAAgEAIgAAVgwIAAgcIAeAAIAAAcgAgXgwIAAgcIAdAAIAAAcg");
	this.shape_53.setTransform(59.1,7.65);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AhMA2IAAggIBVAAQAAgYgNgMQgPgLgfAAIAAgcQAgAAAMAFQAxARAAA1IAiAAIAAAgg");
	this.shape_54.setTransform(45.075,9.925);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AggAvQAgAAAAggIAAhXIAhAAIAABUQAAAhgQAPQgQANghAAg");
	this.shape_55.setTransform(31.825,11.875);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgQBNIAAiZIAgAAIAACZg");
	this.shape_56.setTransform(24.55,7.65);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgXBEQhOgBAAhCIAAgpIAgAAIAAApQAAAVAOAIQAJAFAYAAIA8AAQAPAAAFgCQAMgFAAgQIAAgzIAgAAIAABEQAAASgKAKQgLAKgTABgAAJgnIAAgcIAeAAIAAAcgAgjgnIAAgcIAeAAIAAAcg");
	this.shape_57.setTransform(10.225,8.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,105,138.1), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOApIAAgJIAIAAQAIAAACgFQACgEAAgIIAAg3IAJAAIAAA6QAAAXgSAAg");
	this.shape.setTransform(-100.675,205.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUASIgTAAIAAgJIAOAAIgBgJQAAgLAIgIQAHgJALAAQAMAAAHAJQAHAHAAAMIgBAJIAQAAIAAAJIgUAAQgHALgOAAQgOAAgGgLgAgLgNQgEAFAAAJQAAAIAEAFQAEAHAHAAQAQAAAAgVQAAgIgEgGQgDgGgJAAQgGAAgFAHg");
	this.shape_1.setTransform(-105.95,207.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAWAdQgMABgHgLQgLALgRgBIgUAAIAAgJIAUAAIAMgBIALgHQgMgPgPgFIAAgKQAQgKAOAAQATAAAOAMIgIANQgGAJgLAHQAFAFAEACIAKAAIARAAIAAAJgAgVgOQAHADAHAGQAFAEAGAIQANgIAHgNIgJgEQgHgCgHgBQgKABgMAGg");
	this.shape_2.setTransform(-114.3,206.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXAeQASABAAgWIAAgvIAIAAIAAAvIAVAAIAAAJIgWAAQgDAUgWABg");
	this.shape_3.setTransform(-120.9,207.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgiAmIAAgJIAYAAQgGgHAAgMQAAgMAHgHQAIgJALABQALAAAIAHQAHAIAAAMQAAAMgHAIQgIAJgMgBgAgHAKQABAKAEAGQADAFAIAAQARAAAAgWQAAgTgQAAQgQgBgBAVgAAFgbIAAgKIAJAAIAAAKg");
	this.shape_4.setTransform(-127.75,205.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAeAsQgSAAgGgSQgFAJgNAAQgKAAgGgIQgHgIAAgNQAAgNAHgJQAHgIAKAAIAaAAIAAAoQAAATAQAAIAFAAIAAAJgAgVgKQgFAGAAAJQAAAKAFAHQAEAGAIAAQAPAAAAgYIAAgWIgPAAQgIAAgEAIgAAAghIAAgLIAJAAIAAALgAgPghIAAgLIAJAAIAAALg");
	this.shape_5.setTransform(-134.575,204.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgDApIAAhRIAHAAIAABRg");
	this.shape_6.setTransform(-141.925,205.325);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOApIAAgJIAIAAQAHAAADgFQACgEAAgIIAAg3IAJAAIAAA6QAAAXgSAAg");
	this.shape_7.setTransform(-145.525,205.325);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgVASIgSAAIAAgJIAOAAIgBgJQAAgMAIgHQAHgJALAAQAMAAAHAJQAHAIAAALIgBAJIAPAAIAAAJIgTAAQgIALgNAAQgOAAgHgLgAgMgNQgDAHAAAHQAAAHADAGQAFAHAHAAQAQAAAAgVQAAgJgEgFQgDgGgJAAQgHAAgFAHg");
	this.shape_8.setTransform(-150.775,207.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgXAoQASAAAAgVIAAgvIAIAAIAAAvIAVAAIAAAJIgVAAQgEATgWACgAgFglIAAgLIAIAAIAAALg");
	this.shape_9.setTransform(-156.875,206.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAGAmIAAgKIAJAAIAAAKgAgKAmIAAgKIAJAAIAAAKgAgOATIAAgJIAIAAQAIAAACgFQACgDAAgIIAAgfIAJAAIAAAjQAAAVgSAAg");
	this.shape_10.setTransform(-161.975,207.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AglAdIAAgJIAtAAQABgRgHgJQgGgMgQgBIgDAAIAAgJQAnAAACAwIAUAAIAAAJg");
	this.shape_11.setTransform(-167.05,206.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgaADIAAgGIAwgUIADAIIgkAPIAmAPIgDAJg");
	this.shape_12.setTransform(-176.6,206.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgaADIAAgGIAwgUIADAIIgkAPIAmAPIgDAJg");
	this.shape_13.setTransform(-183.075,206.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(-185.7,200.5,86.49999999999999,11), null);


(lib.txtara = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Group_1();
	this.instance.parent = this;
	this.instance.setTransform(0.05,0,1,1,0,0,0,52.5,69);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.8)",1,1,3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.txtara, new cjs.Rectangle(-55.4,-72,114,148), null);


(lib.endlessicon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(-117.95,238.8,1,1,0,0,0,25,14.1);

	this.instance_1 = new lib.Path_0();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-117.5,189.9,1,1,0,0,0,29.6,15.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.endlessicon, new cjs.Rectangle(-147.1,174.8,59.19999999999999,78), null);


(lib._250icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(0.5,92.9,1,1,0,0,0,55.5,15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").p("ABmA5QAOAAALgKQAKgKAAgOIAAhxQAAgOgKgKQgLgKgOAAIjMAAQgOAAgKAKQgKAKAAAOIAABxQAAAOAKAKQAKAKAOAAIB/AAIBCA+IAAg+g");
	this.shape.setTransform(-12.05,28.3779);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(1.7,1,1).p("ABEAAIiHAA");
	this.shape_1.setTransform(-12.075,27.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.7,1,1).p("ABEAAIiHAA");
	this.shape_2.setTransform(-12.075,22.65);

	this.instance_1 = new lib.Path_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.35,48.45,1,1,0,0,0,12.1,21.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(1.7,1,1).p("AgfAAIA+AA");
	this.shape_3.setTransform(0.35,63);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.instance_1},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib._250icon, new cjs.Rectangle(-55,14.9,111,93.1), null);


// stage content:
(lib._160x600_ara = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_226 = function() {
		if (!this.looped) this.looped = 1;
		if (this.looped++ < 2) {
			this.gotoAndPlay(2);
		}else{
			this.stop();
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(226).call(this.frame_226).wait(1));

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQA3QgLgEgHgHQgHgIgEgKQgFgLAAgPQAAgMAEgMQAEgKAHgJQAHgGAKgFQAJgEAKAAQALAAAJADQAKAEAGAHQAGAIAEALQAEALAAAQIAAAFIhIAAQABAOAIAHQAIAGALAAIALgBIAKgDIALgGIAHAXIgFAEIgJADIgNADQgGACgJAAQgJAAgLgEgAgMgdQgHAFgBALIAqAAIgDgKIgFgHIgGgEIgHgBQgHAAgGAGg");
	this.shape.setTransform(119.275,581.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAVA5IAAg/QAAgNgFgGQgGgIgJABQgGgBgFAEIgKAHIAABPIgdAAIAAhvIAaAAIACAJQAGgFAJgDQAIgEAIAAQAKABAGACQAIACAFAGQAFAGADAJQADAKAAANIAABBg");
	this.shape_1.setTransform(107.425,581.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgXA1QgJgEgHgJQgIgJgCgKQgEgKAAgLQAAgLAEgKQADgKAHgJQAHgIAJgFQAKgFANAAQAOAAAKAFQAJAFAHAIQAHAJADAKQAEAKAAALQAAALgEAKQgCAKgIAJQgGAJgKAEQgLAGgNAAQgMAAgLgGgAgKgfQgFADgDAEQgDAEgCAHQgBAGAAAHQAAAHABAGQACAHADAEQAEAFAEACQAFADAFAAQAGAAAFgDQAEgCAEgFQADgEACgHQABgGAAgHQAAgHgBgGQgCgHgDgEQgDgEgFgDQgFgDgGAAQgFAAgFADg");
	this.shape_2.setTransform(95.225,581.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgXBPIAAhYIgOAAIAAgXIAOAAIAAgGQAAgKADgJQADgHAFgFQAGgFAGgCQAFgCAIAAQAMAAAFACIAIACIgCAYIgGgCIgLgBQgGAAgEAEQgEAEAAAHIAAAGIAYAAIAAAXIgYAAIAABYg");
	this.shape_3.setTransform(86.35,578.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgWA4QgIgDgEgEQgFgEgDgHQgDgGAAgJQAAgJADgGQADgGAGgEQAHgFAGgCIAPgEIAWgDIAAgBQAAgKgFgEQgFgEgHAAIgJABIgIADIgLAHIgJgUIAFgEIAKgFIAMgDQAHgCAHAAQAKAAAHACQAHADAGAFQAGAGADAHQADAKAAAKIAABHIgaAAIgBgIQgHAFgFADQgHADgIAAQgHAAgHgDgAgBAGQgJABgEAFQgDAEAAAGQAAAGAEADQAEADAHAAQAGAAAEgCIAJgGIAAgXg");
	this.shape_4.setTransform(76.375,581.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWBKQgKgGgFgHQgHgIgCgLQgDgKAAgMQAAgLADgKQAEgMAGgHQAHgIAJgEQAJgGANAAQAJAAALAEIAAgsIAdAAIAACaIgbAAIgBgJQgEAFgHAEQgHADgHAAQgKAAgKgFgAgGgLQgEACgFAGQgDADgBAGQgCAGAAAHQAAAHABAGQABAIADADQAEAGAEACQAFADAGAAQAFAAAGgDQAFgCADgFIAAg3QgIgCgIAAQgGAAgGACg");
	this.shape_5.setTransform(64.95,579.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgXA1QgKgEgHgJQgGgIgEgLQgDgLAAgKQAAgKADgLQAFgMAFgHQAHgJAKgEQAKgFANAAQAOAAAJAFQAKAFAHAIQAGAHAEAMQAEANAAAIQAAAJgEAMQgEALgGAIQgHAJgKAEQgKAGgNAAQgNAAgKgGgAgKgfQgEACgEAFQgDAFgCAGQgCAGAAAHQAAAHACAGQACAHADAEQADAEAFADQAEADAGAAQAGAAAFgDQADgCAFgFIAFgLQABgGAAgHQAAgHgBgGIgFgLQgEgFgEgCQgFgDgGAAQgFAAgFADg");
	this.shape_6.setTransform(53.075,581.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgLA4IgvhvIAfAAIAcBJIAchJIAeAAIguBvg");
	this.shape_7.setTransform(41.525,581.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E01021").s().p("AhKB0QgkgkgBg3QAAgjASgkQARghAbgXQAagVAggNQAhgMAfAAQAKAAAFABQgcAGgTAXQgUAXAAAdIABAEQBaAWAABRQAAApgdAgQggAjgxAAIgBAAQgqAAghghg");
	this.shape_8.setTransform(80.625,540.4504);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AiPCPQg7g7AAhUQAAhTA7g7QA8g8BTAAQBUAAA7A8QA8A7AABTQAABUg8A7Qg7A8hUAAQhTAAg8g8g");
	this.shape_9.setTransform(80.7,544.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(227));

	// Layer_9
	this.instance = new lib._250icon();
	this.instance.parent = this;
	this.instance.setTransform(-46.4,112.3,1,1,0,0,0,41.8,44.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(108).to({_off:false},0).to({x:121.5},12,cjs.Ease.quadOut).wait(107));

	// Layer_10
	this.instance_1 = new lib.endlessicon();
	this.instance_1.parent = this;
	this.instance_1.setTransform(341.1,118.55,1,1,0,0,0,30.9,38.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(118).to({_off:false},0).to({x:228.45},12,cjs.Ease.quadOut).wait(97));

	// Layer_12
	this.instance_2 = new lib.terms();
	this.instance_2.parent = this;
	this.instance_2.setTransform(286.4,254.85,1,1,0,0,0,32.6,2.7);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(134).to({_off:false},0).to({alpha:1},9,cjs.Ease.quadOut).wait(84));

	// FlashAICB
	this.instance_3 = new lib.cta();
	this.instance_3.parent = this;
	this.instance_3.setTransform(263,197.45,1,1,0,0,0,40.5,5.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(151).to({_off:false},0).to({alpha:1},9).wait(67));

	// Layer_8
	this.instance_4 = new lib.red();
	this.instance_4.parent = this;
	this.instance_4.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(95).to({_off:false},0).to({alpha:0.8984},12).wait(120));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_4 = new cjs.Graphics().p("AgYBLQg+gGgSgkQgJgRAEgTQADgUANgPQAXgcAsgHQAWgDAhACQAxAEATAWQAMAOACAUQACATgIARQgQAhgoAOQgWAHgbAAIgYgBg");
	var mask_graphics_5 = new cjs.Graphics().p("AiECWQgSgKgJgRQgKgRADgVQADgVAOgNQAJgJABgCQADgFAAgNIgBhaQgBgnALgTQAJgRAVgJQAUgIAUAEQAUAEAQAPQAQAOAHATQAJAXAAAZIATgEQAWgEAhADQAxAEAUAWQAMAOACAUQACASgJARQgPAigpANQgdAKgqgEIgEAFQgQAPgTADQgKABgDACIgJAKQgMAQgSAJQgSAKgTABIgEAAQgSAAgQgJg");
	var mask_graphics_6 = new cjs.Graphics().p("AhMCbQgNgHgIgKQgTASgYAEQgUADgTgGQgTgHgMgQQgLgQgCgYQgCgjAVgTIAJgIIAJgJQAFgHACgNQACgOgBgYIgBgpQACgzAagVQAPgNAWgBQAVgCASAKQALAFAJAJQAGgEAIgDQAUgIAUAEQATAEAQAPQAQAOAIATQAKAXgBAZIATgEQAWgEAhADQAxAEAUAWQAMAOACATQACATgJARQgPAigpANQgdAKgqgEIgEAFQgQAPgUADQgKABgDACIgJAKQgMAQgRAJQgSAKgTABIgDAAQgSAAgRgJg");
	var mask_graphics_7 = new cjs.Graphics().p("AAACbQgNgHgIgKQgTASgYAEQgUADgTgGQgTgHgMgQQgJgNgDgTIgFAAIgVACIgTAKQgdAPgcgIQgfgJgNgbQgIgQABgUQACgTAKgQIAFgKQACgFgEgLQgOglAAgdQACgoAagUQAXgSArACQArABAfAQQATAJAOAOQAHgWAPgMQAPgNAWgBQAVgCARAKQAKAFAKAJQAGgEAIgDQAUgIAUAEQAUAEAQAPQAQAOAIATQAKAXgBAZIATgEQAWgEAhADQAxAEAUAWQAMAOACATQACATgJARQgPAigpANQgdAKgqgEIgEAFQgQAPgUADQgKABgDACIgJAKQgMAQgSAJQgSAKgTABIgEAAQgSAAgPgJg");
	var mask_graphics_8 = new cjs.Graphics().p("ABVCbQgNgHgJgKQgTASgYAEQgUADgRgGQgUgHgLgQQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgngQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFQgYgHgNgPQgWgaAKguQAGgWACgLIACgVQAAgNACgIQAHgbAYgPQAZgOAbAHQAQAFARAOIAdAaIASAPQgHgXABgTQACgoAZgUQAXgSArACQAsABAeAQQAUAJAOAOQAHgWAOgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACATQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABIgEAAQgSAAgQgJg");
	var mask_graphics_9 = new cjs.Graphics().p("AmKCmQgQgIgKgPQgKgPgCgTQgBgSAHgRIAMgYQAEgLAFgVIAFgcQAGgdAEgLQAIgYATgOQAWgQAXADQAJABANAGIAGgEQAYgOAcAHQAPAFASAOIAcAaIASAQQgGgYAAgTQACgoAagUQAXgSArACQArABAeAQQATAKAOANQAHgWAPgMQAPgNAWgBQAVgCASAKQAKAFAKAJQAGgEAIgDQAUgIAUAEQAUAEAQAPQAQAOAIATQAKAXgBAZIATgEQAWgEAhADQAxAEAUAWQAMAOACAUQACASgJARQgPAigpANQgdALgqgEIgEAEQgQAPgUADQgKABgDACIgJAKQgMAQgSAJQgSAKgTABQgUABgSgKQgNgHgIgKQgTASgYAEQgUADgTgGQgTgHgLgQQgJgNgDgTIgFAAIgIABQgOAHgUAIQhCAWgogQIgLgDQgFgBgMAFQgKADgNABIgXAAQgcgCgRgFIgJgDQgFAOgGAKQgVAhghAFIgHAAQgOAAgOgGg");
	var mask_graphics_10 = new cjs.Graphics().p("AlvC1QgRgIgKgPQgGgJgDgMQgLgHgKgJQgWgWgHgdQgEgPgBgZQgBgZADgpQADgyAAgSQAAgZADgMQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIgBATQAQgHAQACQAJABANAGIAFgEQAZgOAbAHQAQAFARAOIAdAaIASAQQgHgYABgTQACgoAZgUQAXgSArACQAsABAdAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACATQACATgIARQgQAigoANQgeAKgpgDIgEAEQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgJgKQgTASgYAEQgUADgSgGQgUgHgLgQQgKgNgDgTIgFAAIgHABQgNAHgVAIQhCAWgngQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFIgIAAQgOAAgNgGg");
	var mask_graphics_11 = new cjs.Graphics().p("AjmC1QgRgIgKgPQgGgJgDgMQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgZAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgDIACgOQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAGIAFgEQAZgOAbAHQAQAFARAOIAdAaIARAQQgGgYABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACATQACATgIARQgQAigoANQgeAKgpgDIgEAEQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgTASgZAEQgUADgSgGQgUgHgLgQQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFIgHAAQgPAAgNgGgAmLAGIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_12 = new cjs.Graphics().p("AIHE+QgUAAgRgNQgRgNgFgTQgEgNAAgXQgBgxAEgYQAGgdAAgHQAAgLgGgWQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgIATADQAUACAOALQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgQALgSAAIgDAAgAjmAyQgRgIgKgPQgGgKgDgLQgLgGgKgJIgMgPIgLAKQgeAXg6AEQg9ADgtgQQg4gUgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAJQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgTASgZAEQgUADgSgGQgUgHgLgQQgKgMgDgTIgFAAIgIABQgNAHgVAIQhCAVgmgPIgMgDQgFgBgMAEQgJADgNABIgYAAQgbgCgRgEIgJgDQgFANgHAKQgVAhggAFIgHAAQgPAAgNgGgAmLh8IgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_13 = new cjs.Graphics().p("AIHE+QgQAAgNgIIgXACIgtAAQgjgBgOgDQgcgFgQgQQgLgLgNgbIgQglIgGgWIgJgWQgJgPgDgIQgLgYAJgZQAIgYAYgMQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgIATADQAUACAOALQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgQALgSAAIgDAAgAjmAyQgRgIgKgPQgGgKgDgLQgLgGgKgJIgMgPIgLAKQgeAXg6AEQg9ADgtgQQg4gUgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAJQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgTASgZAEQgUADgSgGQgUgHgLgQQgKgMgDgTIgFAAIgIABQgNAHgVAIQhCAVgmgPIgMgDQgFgBgMAEQgJADgNABIgYAAQgbgCgRgEIgJgDQgFANgHAKQgVAhggAFIgHAAQgPAAgNgGgAmLh8IgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_14 = new cjs.Graphics().p("AIHE+QgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbQgNgGgfgXQgqgggNgZQgYgrARg9QAMgqAZgYQAOgOASgGQgIgFgFgIQgKgMgDgTIgFAAIgIABQgNAHgVAIQhCAVgmgPIgMgDQgFgBgMAEQgJADgNABIgYAAQgbgCgRgEIgJgDQgFANgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgGgKgJIgMgPIgLAKQgeAXg6AEQg9ADgtgQQg4gUgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAJQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgIATADQAUACAOALQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgQALgSAAIgDAAgAmLh8IgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_15 = new cjs.Graphics().p("AIHE+QgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgTgNgNgTQgNgTgDgWQgBgMACgaIAFhGQACgYAEgMQAHgZARgNQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgFQgIgFgFgIQgKgMgDgTIgFAAIgIABQgNAHgVAIQhCAVgmgPIgMgDQgFgBgMAEQgJADgNABIgYAAQgbgCgRgEIgJgDQgFANgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgGgKgJIgMgPIgLAKQgeAXg6AEQg9ADgtgQQg4gUgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAJQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgIATADQAUACAOALQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgQALgSAAIgDAAgAmLh8IgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_16 = new cjs.Graphics().p("AIHE+QgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgJgGgIgIQgWAogiALQgRAFgSgDQgSgDgOgKQgMgKgHgOQgGgOAAgQQABgPAIgOQAHgOANgIQAIgFADgEQACgDADgKIAIgvQAEgiALgRQALgQATgIQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgFQgIgFgFgIQgKgMgDgTIgFAAIgIABQgNAHgVAIQhCAVgmgPIgMgDQgFgBgMAEQgJADgNABIgYAAQgbgCgRgEIgJgDQgFANgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgGgKgJIgMgPIgLAKQgeAXg6AEQg9ADgtgQQg4gUgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAJQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgIATADQAUACAOALQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgQALgSAAIgDAAgAmLh8IgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_17 = new cjs.Graphics().p("AkWElQgqgigThIQgOg4AUgeQAKgPARgHQARgHASADQARACAPAMQAOAMAGARQAEAJADARIAFAbQAFAQAKADQAKADAIgJQAGgGAFgLQAJgYAEgdQADgkAFgMQAHgSASgLQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgGgFgHQgKgMgDgTIgFAAIgIAAQgNAIgVAHQhCAWgmgPIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAMgHALQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgGgKgKIgMgOIgLAKQgeAXg6ADQg9AEgtgPQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAPgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgIQARgIATACQAUACAOALQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHASgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgXQgJgGgIgIQgWAngiALIgFACQgTAGgVgFQgZgHgNgUQgqAjgzADIgMABQguAAgmgegAmLiBIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AkWElQgqgigThIQgOg4AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgGgFgHQgKgMgDgTIgFAAIgIAAQgNAIgVAHQhCAWgmgPIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAMgHALQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgGgKgKIgMgOIgLAKQgeAXg6ADQg9AEgtgPQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAPgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgIQARgIATACQAUACAOALQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHASgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgXQgJgGgIgIQgWAngiALIgFACQgTAGgVgFQgZgHgNgUQgqAjgzADIgMABQguAAgmgegAmLiBIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_19 = new cjs.Graphics().p("AFoGzQgOgLgHgSQgHgSAEgSQAEgSANgOQANgOASgEIASgEIAMgIQAagTAoABQAXABAUAIQAVAKALARQAKAOAAASQABASgJAQQgIAPgPAJQgQAJgRAAQgMAAgDACQgDABgHAGQgXARglAAQgjAAgVgQgAkWClQgqgjgThIQgOg3AUgdQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgEQgIgGgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgDIACgOQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAGIAFgEQAZgOAbAHQAQAFARAOIAdAaIARAQQgGgYABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgDIgEAEQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAAMgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgJgGgIgHQgWAngiALIgFABQgTAHgVgGQgZgHgNgTQgqAjgzADIgMAAQguAAgmgdgAmLkBIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_20 = new cjs.Graphics().p("AEzHNQgYgEgQgGQgZgHgPgNQgUgPgGgVQgEgOADgdQADgfAKgMIAJgMQACgEAAgMQAAgUAJgTQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFAMIAHgFQAagTAoABQAXABAUAIQAVAKALARQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgFgHgIQgMACgMAAIgMAAIgDADQgOAVgWAGQgHACgLAAQgQAAgYgGgAkWCVQgqgjgThIQgOg2AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANALAGANQAKgKAOgHQARgGARACQAIgRANgLQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgEQgIgGgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgJgDgMQgLgGgKgKIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgDIACgOQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAGIAFgEQAZgOAbAHQAQAFARAOIAdAaIARAQQgGgXABgUQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeALgpgEIgEAEQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgGgIgLQgOANgRAGQAIAGAHAHQAKAKAJAPQAGgFAIgFQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAWQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAHgdgCQgzgDgjgXQgJgGgIgHQgWAngiALIgFABQgTAHgVgGQgZgHgNgTQgqAjgzADIgMAAQguAAgmgdgAmLkRIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_21 = new cjs.Graphics().p("AAvHGQgagQgKgUQgFgJgCgNIgEgYIgQhVQgJgxAGgjQAFgZALgOQAOgUAYgEQAfgFAXATQAXATABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADIgNABQggAAgggVgAkWCNQgqgigThIQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgGgFgHQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFANgHALQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAXQgFAZAAALIAAAmQAAAWgFAOQgHASgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgXQgJgGgIgIQgWAngiALIgFACQgTAGgVgFQgZgHgNgUQgqAjgzADIgMABQguAAgmgegAmLkZIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_22 = new cjs.Graphics().p("AAvHGQgagQgKgUQgFgJgCgNIgDgPIgCAFQgOAUgWAMQgeARgegBQgjgCgVgYQgTgUgBgeQgCgZAKgeQADgIgBgEIgCgKQgNgkARgdQAJgQARgJQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgOQAOgUAYgEQAfgFAXATQAXATABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADIgNABQggAAgggVgAkWCNQgqgigThIQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgGgFgHQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFANgHALQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAXQgFAZAAALIAAAmQAAAWgFAOQgHASgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgXQgJgGgIgIQgWAngiALIgFACQgTAGgVgFQgZgHgNgUQgqAjgzADIgMABQguAAgmgegAmLkZIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_23 = new cjs.Graphics().p("AAvHGQgagQgKgUQgFgJgCgNIgDgPIgCAFQgOAUgWAMQgeARgegBQgKgBgIgCIgRADQgsAEhGgaQgpgQgTgLQgfgVgNgbQgRgnATg/QAVhHArgVIAGgCQgqgjgThHQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgGgFgHQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFANgHALQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAXQgFAZAAALIAAAmQAAAWgFAOQgHASgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgXQgJgGgIgIQgWAngiALIgFACQgTAGgVgFQgZgHgNgUQgeAZgiAJQAKALAGAPIACgBQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgOQAOgUAYgEQAfgFAXATQAXATABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADIgNABQggAAgggVgAmLkZIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AHhJMQgSAAgRgMQgQgLgHgRQgJgYAJgvIAGgiQAFgbAFgNQAHgVAMgNQAQgQAWgDQAXgEAUAKQATAKAJAWQAJAVgFAVIgJAXQgEAMgCALIgFAeQgEAggFANQgIARgRAKQgQAKgSAAIgCAAgAAvFUQgagQgKgUQgFgJgCgNIgDgOIgCAFQgOATgWANQgeARgegCQgKAAgIgCIgRACQgsAFhGgaQgpgQgTgMQgfgUgNgcQgRgnATg/QAVhHArgUIAGgDQgqghgThIQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgEQgIgGgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAGIAFgEQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgDIgEAEQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFANQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgJgGgIgHQgWAngiALIgFABQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAQIACgCQARgJATAAQAkAAAfAbQAHAGAFABIABgNQAFgZALgOQAOgTAYgEQAfgGAXATQAXATABAfQAAAIgCAPQgDAPAAAIQAQgNAXgCQAUgBAVAHQARAGAUAMQACgMAGgMQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFAMIAHgFQAagTAoABQAXABAUAIQAVAKALARQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgFgHgIQgMACgMAAIgMAAIgDADQgOAVgWAGQgUAFgmgJQgYgEgQgGQgZgHgPgNQgJgHgGgIQgHgEgGgFQgJAYgFAJQgKARgQALQgQALgTACIgNABQggAAgggVgAmLmKIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_25 = new cjs.Graphics().p("AGFJhQgUgGgNgOIgHgHQgDgCgIgBQgbgFgQgWQgMgRgCgbQgCgQADggQACgVAFgMQAFgNANgLQALgJAPgEQAdgIAeANQAGADAFABIALgBQAKgBAKACIAFgTQAHgWAMgMQAQgQAWgEQAXgEAUALQATAKAJAVQAJAWgFAVIgJAXQgEALgCAMIgFAdQgEAhgFAMQgIARgRALQgRAKgTAAIgJgBQgEANgKALQgNAPgSAGQgJADgKAAQgJAAgKgDgAAvE9QgagQgKgUQgFgJgCgNIgDgPIgCAFQgOAUgWAMQgeARgegBQgKgBgIgCIgRADQgsAEhGgaQgpgQgTgLQgfgVgNgbQgRgnATg/QAVhHArgVIAGgCQgqgigThHQgOg4AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAOgHAKQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHARgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgWQgJgGgIgIQgWAmgiALIgFACQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAPIACgBQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgOQAOgUAYgEQAfgEAXASQAXATABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADIgNABQggAAgggVgAmLmiIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_26 = new cjs.Graphics().p("AGFJhQgUgGgNgOIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWAAQgVAAgSgNQgSgOgGgUIgFgTIgIgTQgJgVAEgkIAEgqQAFgXADgIQAJgTAUgLQAUgLAVAEQAVADAQARQALANAEAPIACAAQAdgIAeANQAGADAFABIALgBQAKgBAKACIAFgTQAHgWAMgMQAQgQAWgEQAXgEAUALQATAKAJAVQAJAWgFAVIgJAXQgEALgCAMIgFAdQgEAhgFAMQgIARgRALQgRAKgTAAIgJgBQgEANgKALQgNAPgSAGQgJADgKAAQgJAAgKgDgAAvE9QgagQgKgUQgFgJgCgNIgDgPIgCAFQgOAUgWAMQgeARgegBQgKgBgIgCIgRADQgsAEhGgaQgpgQgTgLQgfgVgNgbQgRgnATg/QAVhHArgVIAGgCQgqgigThHQgOg4AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAOgHAKQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHARgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgWQgJgGgIgIQgWAmgiALIgFACQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAPIACgBQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgOQAOgUAYgEQAfgEAXASQAXATABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADIgNABQggAAgggVgAmLmiIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_27 = new cjs.Graphics().p("AGFJhQgUgGgNgOIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWAAQgVAAgSgNQgHgGgGgGQgQARgZAEQgSACgegJQglgLgSgRQgSgSgKggQgIgYADgSQADgWASgVQANgPAagOQAUgLARgEQAdgGAhANIABgEQAJgTAUgLQAUgLAVAEQAVADAQARQALANAEAPIACAAQAdgIAeANQAGADAFABIALgBQAKgBAKACIAFgTQAHgWAMgMQAQgQAWgEQAXgEAUALQATAKAJAVQAJAWgFAVIgJAXQgEALgCAMIgFAdQgEAhgFAMQgIARgRALQgRAKgTAAIgJgBQgEANgKALQgNAPgSAGQgJADgKAAQgJAAgKgDgAAvE9QgagQgKgUQgFgJgCgNIgDgPIgCAFQgOAUgWAMQgeARgegBQgKgBgIgCIgRADQgsAEhGgaQgpgQgTgLQgfgVgNgbQgRgnATg/QAVhHArgVIAGgCQgqgigThHQgOg4AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAOgHAKQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHARgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgWQgJgGgIgIQgWAmgiALIgFACQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAPIACgBQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgOQAOgUAYgEQAfgEAXASQAXATABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADIgNABQggAAgggVgAmLmiIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_28 = new cjs.Graphics().p("AGFJhQgUgGgNgOIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWAAQgVAAgSgNQgHgGgGgGQgQARgZAEQgSACgegJIgBAAIgMACQgyAHgygKQgbgGgOgLQgSgNgJgcQgFgSABgfQABgcAFgcIAKgxIADgiQACgUAGgNQAJgRAQgJIAEgCIgEgQIgDgPIgCAFQgOAUgWAMQgeARgegBQgKgBgIgCIgRADQgsAEhGgaQgpgQgTgLQgfgVgNgbQgRgnATg/QAVhHArgVIAGgCQgqgigThHQgOg4AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAOgHAKQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHARgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgWQgJgGgIgIQgWAmgiALIgFACQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAPIACgBQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgOQAOgUAYgEQAfgEAXASQAXATABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADQgLACgMgCQAAAMgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgEQAJgTAUgLQAUgLAVAEQAVADAQARQALANAEAPIACAAQAdgIAeANQAGADAFABIALgBQAKgBAKACIAFgTQAHgWAMgMQAQgQAWgEQAXgEAUALQATAKAJAVQAJAWgFAVIgJAXQgEALgCAMIgFAdQgEAhgFAMQgIARgRALQgRAKgTAAIgJgBQgEANgKALQgNAPgSAGQgJADgKAAQgJAAgKgDgAmLmiIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_29 = new cjs.Graphics().p("Ah0KAQgWgKgKgTQgGgNgDgaQgFgrAOgYIAIgMQAFgHACgGQACgHgBgKIgDgSQgFgaAFgTQAFgSAQgNQAPgNATgCIASAAQAKAAAHgCIALgDIACgNIADgiQACgUAGgNQAJgRAQgJIAEgCIgEgQIgDgPIgCAFQgOAUgWAMQgeARgegBQgKgBgIgCIgRADQgsAEhGgaQgpgQgTgLQgfgVgNgbQgRgnATg/QAVhGArgVIAGgCQgqgjgThHQgOg4AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgGgFgHQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAOgHAKQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHASgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgXQgJgGgIgIQgWAngiALIgFACQgTAGgVgFQgZgHgNgUQgeAZgiAJQAKAKAGAPIACgBQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgNQAOgUAYgEQAfgFAXATQAXASABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADQgLACgMgCQAAAMgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgEQAJgTAUgLQAUgLAVAEQAVADAQARQALANAEAPIACAAQAdgIAeANQAGADAFABIALgBQAKgBAKACIAFgTQAHgWAMgMQAQgQAWgEQAXgEAUALQATAKAJAVQAJAWgFAVIgJAXQgEALgCAMIgFAdQgEAhgFAMQgIARgRALQgRAKgTAAIgJgBQgEANgKALQgNAPgSAGQgTAFgTgFQgUgGgNgOIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWAAQgVAAgSgNQgHgGgGgGQgQARgZAEQgSACgegJIgBAAIgMACQgyAHgygKQgZgFgNgKIgGAKQgFAKgBAFIAAATQABAWgNATQgOATgVAGQgJADgIAAQgNAAgNgGgAmLnEIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_30 = new cjs.Graphics().p("Ah0KAQgWgKgKgTQgFgMgDgVIgQgMQgEgEgEAAIgHADQgbAQgegNQgOgGgKgMQgJgLgEgPQgHgbAQggQAHgMgBgGQgBgEgFgJQgNgYAIgaQAIgZAYgMQAHgEAKgDIATgFIAugOQAbgGAUAEQAbAHAOAXIADAFIAKAAQAKAAAHgCIALgDIACgNIADgiQACgUAGgNQAJgRAQgJIAEgCIgEgQIgDgPIgCAFQgOAUgWAMQgeARgegBQgKgBgIgCIgRADQgsAEhGgaQgpgQgTgLQgfgVgNgbQgRgnATg/QAVhGArgVIAGgCQgqgjgThHQgOg4AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgGgFgHQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAOgHAKQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHASgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgXQgJgGgIgIQgWAngiALIgFACQgTAGgVgFQgZgHgNgUQgeAZgiAJQAKAKAGAPIACgBQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgNQAOgUAYgEQAfgFAXATQAXASABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADQgLACgMgCQAAAMgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgEQAJgTAUgLQAUgLAVAEQAVADAQARQALANAEAPIACAAQAdgIAeANQAGADAFABIALgBQAKgBAKACIAFgTQAHgWAMgMQAQgQAWgEQAXgEAUALQATAKAJAVQAJAWgFAVIgJAXQgEALgCAMIgFAdQgEAhgFAMQgIARgRALQgRAKgTAAIgJgBQgEANgKALQgNAPgSAGQgTAFgTgFQgUgGgNgOIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWAAQgVAAgSgNQgHgGgGgGQgQARgZAEQgSACgegJIgBAAIgMACQgyAHgygKQgZgFgNgKIgGAKQgFAKgBAFIAAATQABAWgNATQgOATgVAGQgJADgIAAQgNAAgNgGgAmLnEIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_31 = new cjs.Graphics().p("Ah0KAQgWgKgKgTQgFgMgDgVIgQgMQgEgEgEAAIgHADQgRAKgTgBQgRACgVAAQg5gBgigNQgzgTgRgqQgMgbAGg3IAGgpQADgXAFgPQAHgaASgVQAQgTATgIQAYgKAcAIQAaAIATAUQATAUAJAcIASgFIAugOQAbgGAUAEQAbAHAOAXIADAFIAKAAQAKAAAHgCIALgDIACgNIADgiQACgUAGgNQAJgRAQgJIAEgCIgEgQIgDgPIgCAFQgOAUgWAMQgeARgegBQgKgBgIgCIgRADQgsAEhGgaQgpgQgTgLQgfgVgNgbQgRgnATg/QAVhGArgVIAGgCQgqgjgThHQgOg4AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgGIAYgLQAPgIAJgCIAFgBIAIgGQASgMAUACQAUABAQANQANALAGAOQAKgLAOgGQARgHARADQAIgSANgLQANgLARgCQARgDAQAGQAQAFALAOIAFAHQALgJAOgFQgIgGgFgHQgKgNgDgTIgFAAIgIAAQgNAIgVAHQhCAXgmgQIgMgEQgFAAgMAEQgJAEgNAAIgYAAQgbgBgRgFIgJgDQgFAOgHAKQgVAhggAEQgSACgRgIQgRgIgKgPQgGgJgDgLQgLgHgKgKIgMgOIgLAKQgeAYg6ADQg9AEgtgQQg4gVgYguQgLgXgBgZQAAgaAMgVQAMgVAZgQQAQgLAggPQA7gZAdgFQAVgDAxACQAMABAGgCIAIgDIACgOQAFgTASgNQAQgMAVgBQAUAAARAMQASALAHATQAHARgBAbIAAATQAPgHAQACQAJABANAGIAFgDQAZgOAbAHQAQAFARANIAdAaIARAQQgGgXABgUQABgnAZgUQAXgTArACQAsACAeAPQAUAKAOAOQAHgWAPgNQAPgNAVgBQAVgBATAJQAKAGAKAJQAGgEAHgEQAUgIAVAEQAUAEAQAPQAQAOAIAUQAJAXgBAZIATgFQAWgDAiACQAxAEATAWQAMAOACAUQACAUgIARQgQAhgoAOQgeAKgpgEIgEAEQgQAQgVADQgKABgCABIgKAKQgMAQgRAKQgSAKgTAAQgUABgSgJQgNgHgIgKQgOANgRAFQAIAGAHAIQAKAKAJAPQAGgGAIgEQATgJAaACQAZADAhARQAPAIAsAaIAJAFIgEgRQgHgVAAgMQgBgSAKgRQAKgQAQgJQARgIATACQAUACAOAMQAOAMAJAVQAGAOAFAZQAGAfgBARQAAANgFAYQgFAZAAALIAAAmQAAAWgFAOQgHASgSAMQgRAMgUgBQgQgBgNgHIgXACIgtgBQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBAAQgdAGgdgCQgzgCgjgXQgJgGgIgIQgWAngiALIgFACQgTAGgVgFQgZgHgNgUQgeAZgiAJQAKAKAGAPIACgBQARgJATgBQAkAAAfAcQAHAGAFABIABgNQAFgZALgNQAOgUAYgEQAfgFAXATQAXASABAfQAAAHgCAPQgDAPAAAIQAQgMAXgCQAUgCAVAHQARAGAUANQACgNAGgLQAJgTAQgMQANgJAZgHQApgJAZANQAPAIAJAOQAJAOACARIACAQQABAKACAHIAFALIAHgEQAagTAoABQAXAAAUAJQAVAJALARQAKAPAAASQABASgJAPIgBADQABALgDALQgGAdgbAPQgNAHgRABQgRABgQgIQgLgFgHgHQgMACgMAAIgMgBIgDAEQgOAUgWAGQgUAGgmgJQgYgFgQgFQgZgIgPgNQgJgGgGgJQgHgDgGgFQgJAXgFAKQgKAQgQALQgQALgTADQgLACgMgCQAAAMgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgEQAJgTAUgLQAUgLAVAEQAVADAQARQALANAEAPIACAAQAdgIAeANQAGADAFABIALgBQAKgBAKACIAFgTQAHgWAMgMQAQgQAWgEQAXgEAUALQATAKAJAVQAJAWgFAVIgJAXQgEALgCAMIgFAdQgEAhgFAMQgIARgRALQgRAKgTAAIgJgBQgEANgKALQgNAPgSAGQgTAFgTgFQgUgGgNgOIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWAAQgVAAgSgNQgHgGgGgGQgQARgZAEQgSACgegJIgBAAIgMACQgyAHgygKQgZgFgNgKIgGAKQgFAKgBAFIAAATQABAWgNATQgOATgVAGQgJADgIAAQgNAAgNgGgAmLnEIgHADIgNAFQAFABAQgCIADgBIAEgGIgEAAIgEAAg");
	var mask_graphics_32 = new cjs.Graphics().p("AH0L2QgTgJgKgSQgGgNgCgRQgCgKAAgWIAAhhIgBgsQgCgcADgLQAEgVASgOQASgPAWAAQAVAAATAOQASAOAGAUQAEAOAAAdIAABRQAAAuABAPQADAegCAIQgCAUgQAQQgPAPgUAEIgLAAQgOAAgPgHgAh0IIQgWgJgKgUQgFgLgDgVIgQgMQgEgEgEAAIgHACQgRAKgTgBQgRACgVAAQg5gBgigNQgzgTgRgpQgMgcAGg3IAGgpQADgXAFgPQAHgaASgUQAQgUATgHQAYgKAcAIQAaAHATAUQATAUAJAdIASgFIAugOQAbgHAUAFQAbAGAOAXIADAFIAKAAQAKAAAHgBIALgEIACgNIADgiQACgUAGgMQAJgRAQgKIAEgCIgEgQIgDgOIgCAFQgOATgWANQgeARgegCQgKAAgIgCIgRACQgsAFhGgaQgpgQgTgMQgfgUgNgcQgRgnATg+QAVhHArgUIAGgDQgqgigThIQgOg3AUgeQAKgPARgHQAPgHAPACQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgIAQADQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAJAOAOQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgDgJgDQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgJgGgIgIQgWAngiAMIgFABQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAQIACgCQARgJATAAQAkAAAfAbQAHAGAFABIABgNQAFgZALgOQAOgTAYgEQAfgGAXATQAXATABAfQAAAIgCAPQgDAPAAAIQAQgNAXgCQAUgBAVAHQARAGAUAMQACgMAGgMQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFALIAHgEQAagTAoABQAXABAUAIQAVAKALAQQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgGgHgHQgMACgMAAIgMAAIgDADQgOAVgWAGQgUAFgmgJQgYgEgQgGQgZgHgPgNQgJgHgGgIQgHgEgGgFQgJAYgFAJQgKARgQALQgQALgTACQgLACgMgBQAAALgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgDQAJgUAUgLQAUgKAVADQAVAEAQAQQALANAEAQIACgBQAdgIAeANQAGAEAFAAIALgBQAKgBAKACIAFgTQAHgVAMgNQAQgQAWgDQAXgEAUAKQATAKAJAWQAJAVgFAVIgJAXQgEAMgCALIgFAeQgEAggFANQgIARgRAKQgRALgTgBIgJgBQgEANgKAMQgNAPgSAFQgTAGgTgGQgUgFgNgPIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWABQgVAAgSgOQgHgFgGgHQgQASgZADQgSADgegJIgBgBIgMACQgyAHgygKQgZgFgNgKIgGALQgFAKgBAEIAAATQABAWgNAUQgOATgVAGQgJACgIAAQgNAAgNgGgAmLo7IgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_33 = new cjs.Graphics().p("AH0L2QgTgJgKgSQgEgJgCgKIgJAFQgPAIgTgBQgTgCgOgMQgOgLgHgRQgGgSACgSIAKghQADgIAHggIAHgoQAFgdAEgLQAJgTAUgKQAUgKAVAEIAHABIAGgFQASgPAWAAQAVAAATAOQASAOAGAUQAEAOAAAdIAABRQAAAuABAPQADAegCAIQgCAUgQAQQgPAPgUAEIgLAAQgOAAgPgHgAh0IIQgWgJgKgUQgFgLgDgVIgQgMQgEgEgEAAIgHACQgRAKgTgBQgRACgVAAQg5gBgigNQgzgTgRgpQgMgcAGg3IAGgpQADgXAFgPQAHgaASgUQAQgUATgHQAYgKAcAIQAaAHATAUQATAUAJAdIASgFIAugOQAbgHAUAFQAbAGAOAXIADAFIAKAAQAKAAAHgBIALgEIACgNIADgiQACgUAGgMQAJgRAQgKIAEgCIgEgQIgDgOIgCAFQgOATgWANQgeARgegCQgKAAgIgCIgRACQgsAFhGgaQgpgQgTgMQgfgUgNgcQgRgnATg+QAVhHArgUIAGgDQgqgigThIQgOg3AUgeQAKgPARgHQAPgHAPACQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgIAQADQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAJAOAOQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgDgJgDQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgJgGgIgIQgWAngiAMIgFABQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAQIACgCQARgJATAAQAkAAAfAbQAHAGAFABIABgNQAFgZALgOQAOgTAYgEQAfgGAXATQAXATABAfQAAAIgCAPQgDAPAAAIQAQgNAXgCQAUgBAVAHQARAGAUAMQACgMAGgMQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFALIAHgEQAagTAoABQAXABAUAIQAVAKALAQQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgGgHgHQgMACgMAAIgMAAIgDADQgOAVgWAGQgUAFgmgJQgYgEgQgGQgZgHgPgNQgJgHgGgIQgHgEgGgFQgJAYgFAJQgKARgQALQgQALgTACQgLACgMgBQAAALgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgDQAJgUAUgLQAUgKAVADQAVAEAQAQQALANAEAQIACgBQAdgIAeANQAGAEAFAAIALgBQAKgBAKACIAFgTQAHgVAMgNQAQgQAWgDQAXgEAUAKQATAKAJAWQAJAVgFAVIgJAXQgEAMgCALIgFAeQgEAggFANQgIARgRAKQgRALgTgBIgJgBQgEANgKAMQgNAPgSAFQgTAGgTgGQgUgFgNgPIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWABQgVAAgSgOQgHgFgGgHQgQASgZADQgSADgegJIgBgBIgMACQgyAHgygKQgZgFgNgKIgGALQgFAKgBAEIAAATQABAWgNAUQgOATgVAGQgJACgIAAQgNAAgNgGgAmLo7IgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_34 = new cjs.Graphics().p("AEOMDQgQgDgOgJQgbgRgOghQgOgbAAgZQAAgfARgUIAFgIQABgDgBgJQgDgYAMgXQANgXAXgKQAZgKAwAGQAsAGAXANQAEgZAEgKQAJgTAUgKQAUgKAVAEIAHABIAGgFQASgPAWAAQAVAAATAOQASAOAGAUQAEAOAAAdIAABRQAAAuABAPQADAegCAIQgCAUgQAQQgPAPgUAEQgUADgUgKQgTgJgKgSQgEgJgCgKIgJAFQgPAIgTgBQgTgCgOgMQgKgHgGgLIgDgCQgPAmgJANQgSAcgaAHQgJADgLAAIgMgBgAh0IBQgWgJgKgUQgFgLgDgVIgQgMQgEgEgEAAIgHACQgRALgTgCQgRADgVgBQg5gBgigNQgzgTgRgpQgMgcAGg3IAGgpQADgXAFgPQAHgaASgUQAQgUATgHQAYgKAcAIQAaAHATAUQATAUAJAdIASgFIAugOQAbgHAUAFQAbAGAOAXIADAFIAKAAQAKAAAHgBIALgEIACgNIADgiQACgUAGgMQAJgRAQgKIAEgCIgEgQIgDgOIgCAFQgOATgWANQgeARgegCQgKAAgIgCIgRACQgsAFhGgaQgpgQgTgMQgfgUgNgcQgRgnATg+QAVhHArgUIAGgDQgqgigThIQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgEQgIgGgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgJgDgMQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgDIACgOQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAGIAFgEQAZgOAbAHQAQAFARAOIAdAaIARAQQgGgYABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgDIgEAEQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAHgdgCQgzgDgjgXQgJgGgIgHQgWAngiALIgFABQgTAHgVgGQgZgHgNgTQgeAZgiAIQAKALAGAQIACgCQARgJATAAQAkAAAfAbQAHAGAFABIABgNQAFgZALgOQAOgTAYgEQAfgGAXATQAXATABAfQAAAIgCAPQgDAPAAAIQAQgNAXgCQAUgBAVAHQARAGAUAMQACgMAGgMQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFAMIAHgFQAagTAoABQAXABAUAIQAVAKALAQQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgFgHgIQgMACgMAAIgMAAIgDADQgOAVgWAGQgUAFgmgJQgYgEgQgGQgZgHgPgNQgJgHgGgIQgHgEgGgFQgJAYgFAJQgKARgQALQgQALgTACQgLACgMgBQAAALgCAOIgFAlIAPgJQAUgLARgEQAdgFAhAMIABgDQAJgUAUgLQAUgKAVADQAVAEAQAQQALANAEAQIACgBQAdgIAeANQAGAEAFAAIALgBQAKgBAKACIAFgTQAHgVAMgNQAQgQAWgDQAXgEAUAKQATAKAJAWQAJAVgFAVIgJAXQgEAMgCALIgFAeQgEAggFANQgIARgRAKQgRALgTgBIgJgBQgEAOgKALQgNAPgSAFQgTAGgTgGQgUgFgNgPIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWABQgVAAgSgOQgHgFgGgHQgQASgZADQgSADgegJIgBAAIgMABQgyAHgygKQgZgFgNgJIgGAKQgFAKgBAEIAAATQABAWgNAUQgOATgVAGQgJACgIAAQgNAAgNgGgAmLpCIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_35 = new cjs.Graphics().p("AEOMDQgQgDgOgJQgbgRgOghIgBgBIgCgBQgGgDgDAAQgDAAgHAEQgiAUgggDQgngDgUgdQgLgRABgVQAAgWANgPIAFgIQABgDgCgJQgFgTAFgSQAFgTAOgMQAVgRAoABQAqACAaATIAIAGIABgCQANgXAXgKQAZgKAwAGQAsAGAXANQAEgZAEgKQAJgTAUgKQAUgKAVAEIAHABIAGgFQASgPAWAAQAVAAATAOQASAOAGAUQAEAOAAAdIAABRQAAAuABAPQADAegCAIQgCAUgQAQQgPAPgUAEQgUADgUgKQgTgJgKgSQgEgJgCgKIgJAFQgPAIgTgBQgTgCgOgMQgKgHgGgLIgDgCQgPAmgJANQgSAcgaAHQgJADgLAAIgMgBgAh0IBQgWgJgKgUQgFgLgDgVIgQgMQgEgEgEAAIgHACQgRALgTgCQgRADgVgBQg5gBgigNQgzgTgRgpQgMgcAGg3IAGgpQADgXAFgPQAHgaASgUQAQgUATgHQAYgKAcAIQAaAHATAUQATAUAJAdIASgFIAugOQAbgHAUAFQAbAGAOAXIADAFIAKAAQAKAAAHgBIALgEIACgNIADgiQACgUAGgMQAJgRAQgKIAEgCIgEgQIgDgOIgCAFQgOATgWANQgeARgegCQgKAAgIgCIgRACQgsAFhGgaQgpgQgTgMQgfgUgNgcQgRgnATg+QAVhHArgUIAGgDQgqgigThIQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgEQgIgGgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgJgDgMQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgDIACgOQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAGIAFgEQAZgOAbAHQAQAFARAOIAdAaIARAQQgGgYABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgDIgEAEQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAHgdgCQgzgDgjgXQgJgGgIgHQgWAngiALIgFABQgTAHgVgGQgZgHgNgTQgeAZgiAIQAKALAGAQIACgCQARgJATAAQAkAAAfAbQAHAGAFABIABgNQAFgZALgOQAOgTAYgEQAfgGAXATQAXATABAfQAAAIgCAPQgDAPAAAIQAQgNAXgCQAUgBAVAHQARAGAUAMQACgMAGgMQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFAMIAHgFQAagTAoABQAXABAUAIQAVAKALAQQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgFgHgIQgMACgMAAIgMAAIgDADQgOAVgWAGQgUAFgmgJQgYgEgQgGQgZgHgPgNQgJgHgGgIQgHgEgGgFQgJAYgFAJQgKARgQALQgQALgTACQgLACgMgBQAAALgCAOIgFAlIAPgJQAUgLARgEQAdgFAhAMIABgDQAJgUAUgLQAUgKAVADQAVAEAQAQQALANAEAQIACgBQAdgIAeANQAGAEAFAAIALgBQAKgBAKACIAFgTQAHgVAMgNQAQgQAWgDQAXgEAUAKQATAKAJAWQAJAVgFAVIgJAXQgEAMgCALIgFAeQgEAggFANQgIARgRAKQgRALgTgBIgJgBQgEAOgKALQgNAPgSAFQgTAGgTgGQgUgFgNgPIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWABQgVAAgSgOQgHgFgGgHQgQASgZADQgSADgegJIgBAAIgMABQgyAHgygKQgZgFgNgJIgGAKQgFAKgBAEIAAATQABAWgNAUQgOATgVAGQgJACgIAAQgNAAgNgGgAmLpCIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_36 = new cjs.Graphics().p("AgLMJQgUAAgQgLQgRgLgHgSQgHgOgBgcQAAgkAIgUQAMggAZgKQAHgCACgDQACgCABgHQAFgoAPgSQALgPAUgGQAUgFASAHQAMAEAJAIQAUgKAfABQAqACAaATIAIAGIABgCQANgXAXgKQAZgKAwAGQAsAGAXANQAEgZAEgKQAJgTAUgKQAUgKAVAEIAHABIAGgFQASgPAWAAQAVAAATAOQASAOAGAUQAEAOAAAdIAABRQAAAuABAPQADAegCAIQgCAUgQAQQgPAPgUAEQgUADgUgKQgTgJgKgSQgEgJgCgKIgJAFQgPAIgTgBQgTgCgOgMQgKgHgGgLIgDgCQgPAmgJANQgSAcgaAHQgPAFgRgDQgQgDgOgJQgbgRgOghIgBgBIgCgBQgGgDgDAAQgDAAgHAEQgiAUgggDQgVgCgPgJIgDAFQgJAQgMAPQgMAPgOAIQgQAJgRAAIgDAAgAh0H8QgWgJgKgUQgFgLgDgVIgQgMQgEgEgEAAIgHACQgRALgTgCQgRADgVgBQg5gBgigNQgzgTgRgpQgMgcAGg3IAGgpQADgXAFgPQAHgaASgUQAQgUATgHQAYgKAcAIQAaAHATAUQATAUAJAdIASgFIAugOQAbgHAUAFQAbAGAOAXIADAFIAKAAQAKAAAHgBIALgEIACgNIADgiQACgUAGgMQAJgRAQgKIAEgCIgEgQIgDgOIgCAFQgOATgWANQgeARgegCQgKAAgIgCIgRACQgsAFhGgaQgpgQgTgMQgfgUgNgcQgRgmATg/QAVhHArgUIAGgDQgqgigThIQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgJgGgIgIQgWAogiALIgFABQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAQIACgCQARgJATAAQAkAAAfAbQAHAGAFABIABgNQAFgZALgOQAOgTAYgEQAfgGAXATQAXATABAfQAAAIgCAPQgDAPAAAIQAQgNAXgCQAUgBAVAHQARAGAUAMQACgMAGgMQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFALIAHgEQAagTAoABQAXABAUAIQAVAKALAQQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgFgHgIQgMACgMAAIgMAAIgDADQgOAVgWAGQgUAFgmgJQgYgEgQgGQgZgHgPgNQgJgHgGgIQgHgEgGgFQgJAYgFAJQgKARgQALQgQALgTACQgLACgMgBQAAALgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgDQAJgUAUgLQAUgKAVADQAVAEAQAQQALANAEAQIACgBQAdgIAeANQAGAEAFAAIALgBQAKgBAKACIAFgTQAHgVAMgNQAQgQAWgDQAXgEAUAKQATAKAJAWQAJAVgFAVIgJAXQgEAMgCALIgFAeQgEAggFANQgIARgRAKQgRALgTgBIgJgBQgEANgKAMQgNAPgSAFQgTAGgTgGQgUgFgNgPIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWABQgVAAgSgOQgHgFgGgHQgQASgZADQgSADgegJIgBgBIgMACQgyAHgygKQgZgFgNgKIgGALQgFAKgBAEIAAATQABAWgNAUQgOATgVAGQgJACgIAAQgNAAgNgGgAmLpHIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_37 = new cjs.Graphics().p("AgLMJQgUAAgQgLQgLgHgHgKQgYABgdAAQgogBgRgJQgVgLgKgZQgJgZAJgWIANgbQAFgNADgRIAEgfQAFgnARgSQAJgLAPgFQgIgHgFgKQgFgLgDgVIgQgMQgEgEgEAAIgHACQgRALgTgCQgRADgVgBQg5gBgigNQgzgTgRgpQgMgcAGg3IAGgpQADgXAFgPQAHgaASgUQAQgUATgHQAYgKAcAIQAaAHATAUQATAUAJAdIASgFIAugOQAbgHAUAFQAbAGAOAXIADAFIAKAAQAKAAAHgBIALgEIACgNIADgiQACgUAGgMQAJgRAQgKIAEgCIgEgQIgDgOIgCAFQgOATgWANQgeARgegCQgKAAgIgCIgRACQgsAFhGgaQgpgQgTgMQgfgUgNgcQgRgmATg/QAVhHArgUIAGgDQgqgigThIQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgJgGgIgIQgWAogiALIgFABQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAQIACgCQARgJATAAQAkAAAfAbQAHAGAFABIABgNQAFgZALgOQAOgTAYgEQAfgGAXATQAXATABAfQAAAIgCAPQgDAPAAAIQAQgNAXgCQAUgBAVAHQARAGAUAMQACgMAGgMQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFALIAHgEQAagTAoABQAXABAUAIQAVAKALAQQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgFgHgIQgMACgMAAIgMAAIgDADQgOAVgWAGQgUAFgmgJQgYgEgQgGQgZgHgPgNQgJgHgGgIQgHgEgGgFQgJAYgFAJQgKARgQALQgQALgTACQgLACgMgBQAAALgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgDQAJgUAUgLQAUgKAVADQAVAEAQAQQALANAEAQIACgBQAdgIAeANQAGAEAFAAIALgBQAKgBAKACIAFgTQAHgVAMgNQAQgQAWgDQAXgEAUAKQATAKAJAWQAJAVgFAVIgJAXQgEAMgCALIgFAeQgEAggFANQgIARgRAKQgRALgTgBIgJgBQgEANgKAMQgNAPgSAFQgTAGgTgGQgUgFgNgPIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWABQgVAAgSgOQgHgFgGgHQgQASgZADQgSADgegJIgBgBIgMACQgyAHgygKQgZgFgNgKIgGALQgFAKgBAEIAAATQABAWgNAUQgMARgTAGQAKAKAFAMQAHASgBAYQgBAMgFAZQAJgJALgFQAHgCACgDQACgCABgHQAFgoAPgSQALgPAUgGQAUgFASAHQAMAEAJAIQAUgKAfABQAqACAaATIAIAGIABgCQANgXAXgKQAZgKAwAGQAsAGAXANQAEgZAEgKQAJgTAUgKQAUgKAVAEIAHABIAGgFQASgPAWAAQAVAAATAOQASAOAGAUQAEAOAAAdIAABRQAAAuABAPQADAegCAIQgCAUgQAQQgPAPgUAEQgUADgUgKQgTgJgKgSQgEgJgCgKIgJAFQgPAIgTgBQgTgCgOgMQgKgHgGgLIgDgCQgPAmgJANQgSAcgaAHQgPAFgRgDQgQgDgOgJQgbgRgOghIgBgBIgCgBQgGgDgDAAQgDAAgHAEQgiAUgggDQgVgCgPgJIgDAFQgJAQgMAPQgMAPgOAIQgQAJgRAAIgDAAgAmLpHIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");
	var mask_graphics_38 = new cjs.Graphics().p("AgLMJQgUAAgQgLQgLgHgHgKQgYABgdAAIgRgBIgKABIguAFQgZAIgNACQghAGgYgPQgNgIgLgPIgTgcQgagkgLgUQgTgjACgcQAAgnAgggQAWgYArgUQAegPAZgDQAfgFAZANQAWAMAOAYIAEgBQgIgHgFgKQgFgLgDgVIgQgMQgEgEgEAAIgHACQgRALgTgCQgRADgVgBQg5gBgigNQgzgTgRgpQgMgcAGg3IAGgpQADgXAFgPQAHgaASgUQAQgUATgHQAYgKAcAIQAaAHATAUQATAUAJAdIASgFIAugOQAbgHAUAFQAbAGAOAXIADAFIAKAAQAKAAAHgBIALgEIACgNIADgiQACgUAGgMQAJgRAQgKIAEgCIgEgQIgDgOIgCAFQgOATgWANQgeARgegCQgKAAgIgCIgRACQgsAFhGgaQgpgQgTgMQgfgUgNgcQgRgmATg/QAVhHArgUIAGgDQgqgigThIQgOg3AUgeQAKgPARgHQAPgGAPABQAOgEAXABQArAAASgHIAYgLQAPgHAJgDIAFgBIAIgGQASgLAUABQAUABAQAOQANAKAGAOQAKgLAOgGQARgHARADQAIgSANgKQANgLARgDQARgDAQAGQAQAGALANIAFAHQALgJAOgFQgIgFgFgIQgKgNgDgTIgFAAIgIABQgNAHgVAIQhCAWgmgQIgMgDQgFgBgMAFQgJADgNABIgYAAQgbgCgRgFIgJgDQgFAOgHAKQgVAhggAFQgSACgRgIQgRgIgKgPQgGgKgDgLQgLgHgKgJIgMgPIgLAKQgeAYg6AEQg9ADgtgQQg4gVgYguQgLgWgBgaQAAgaAMgVQAMgUAZgRQAQgLAggOQA7gaAdgFQAVgDAxACQAMABAGgBIAIgEIACgNQAFgTASgNQAQgNAVAAQAUgBARAMQASAMAHASQAHASgBAbIAAATQAPgHAQACQAJABANAFIAFgDQAZgOAbAHQAQAFARAOIAdAaIARAPQgGgXABgTQABgoAZgUQAXgSArACQAsABAeAQQAUAKAOANQAHgWAPgMQAPgNAVgBQAVgCATAKQAKAFAKAJQAGgEAHgDQAUgIAVAEQAUAEAQAPQAQAOAIATQAJAXgBAZIATgEQAWgEAiADQAxAEATAWQAMAOACAUQACATgIARQgQAigoANQgeAKgpgEIgEAFQgQAPgVADQgKABgCACIgKAKQgMAQgRAJQgSAKgTABQgUABgSgKQgNgHgIgKQgOANgRAGQAIAFAHAIQAKAKAJAPQAGgGAIgEQATgJAaADQAZADAhARQAPAHAsAaIAJAGIgEgSQgHgVAAgLQgBgSAKgRQAKgRAQgIQARgJATADQAUACAOAMQAOALAJAVQAGAPAFAZQAGAfgBARQAAANgFAXQgFAZAAAMIAAAlQAAAWgFAOQgHATgSALQgRAMgUgBQgQAAgNgIIgXACIgtAAQgjgBgOgDQgMgCgJgEQhVAXg3gbIgBgBQgdAGgdgBQgzgDgjgXQgJgGgIgIQgWAogiALIgFABQgTAHgVgGQgZgHgNgTQgeAYgiAJQAKALAGAQIACgCQARgJATAAQAkAAAfAbQAHAGAFABIABgNQAFgZALgOQAOgTAYgEQAfgGAXATQAXATABAfQAAAIgCAPQgDAPAAAIQAQgNAXgCQAUgBAVAHQARAGAUAMQACgMAGgMQAJgTAQgLQANgKAZgGQApgJAZANQAPAIAJAOQAJAOACAQIACARQABAKACAGIAFALIAHgEQAagTAoABQAXABAUAIQAVAKALAQQAKAOAAASQABASgJAQIgBADQABAKgDALQgGAegbAOQgNAHgRABQgRABgQgHQgLgFgHgIQgMACgMAAIgMAAIgDADQgOAVgWAGQgUAFgmgJQgYgEgQgGQgZgHgPgNQgJgHgGgIQgHgEgGgFQgJAYgFAJQgKARgQALQgQALgTACQgLACgMgBQAAALgCAOIgFAlIAPgJQAUgLARgEQAdgGAhANIABgDQAJgUAUgLQAUgKAVADQAVAEAQAQQALANAEAQIACgBQAdgIAeANQAGAEAFAAIALgBQAKgBAKACIAFgTQAHgVAMgNQAQgQAWgDQAXgEAUAKQATAKAJAWQAJAVgFAVIgJAXQgEAMgCALIgFAeQgEAggFANQgIARgRAKQgRALgTgBIgJgBQgEANgKAMQgNAPgSAFQgTAGgTgGQgUgFgNgPIgHgHQgDgCgIgBQgIgBgGgDIgGAFQgSAOgWABQgVAAgSgOQgHgFgGgHQgQASgZADQgSADgegJIgBgBIgMACQgyAHgygKQgZgFgNgKIgGALQgFAKgBAEIAAATQABAWgNAUQgMARgTAGQAKAKAFAMQAHASgBAYIgDATIAFAAQAKgBAKACIABgCQACgCABgHQAFgoAPgSQALgPAUgGQAUgFASAHQAMAEAJAIQAUgKAfABQAqACAaATIAIAGIABgCQANgXAXgKQAZgKAwAGQAsAGAXANQAEgZAEgKQAJgTAUgKQAUgKAVAEIAHABIAGgFQASgPAWAAQAVAAATAOQASAOAGAUQAEAOAAAdIAABRQAAAuABAPQADAegCAIQgCAUgQAQQgPAPgUAEQgUADgUgKQgTgJgKgSQgEgJgCgKIgJAFQgPAIgTgBQgTgCgOgMQgKgHgGgLIgDgCQgPAmgJANQgSAcgaAHQgPAFgRgDQgQgDgOgJQgbgRgOghIgBgBIgCgBQgGgDgDAAQgDAAgHAEQgiAUgggDQgVgCgPgJIgDAFQgJAQgMAPQgMAPgOAIQgQAJgRAAIgDAAgAmLpHIgHADIgNAFQAFABAQgDIADgBIAEgFIgEgBIgEABg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(4).to({graphics:mask_graphics_4,x:138.193,y:45.0904}).wait(1).to({graphics:mask_graphics_5,x:132.543,y:43.8381}).wait(1).to({graphics:mask_graphics_6,x:126.9139,y:43.3445}).wait(1).to({graphics:mask_graphics_7,x:119.3322,y:43.3445}).wait(1).to({graphics:mask_graphics_8,x:110.7902,y:43.3445}).wait(1).to({graphics:mask_graphics_9,x:106.0308,y:44.2098}).wait(1).to({graphics:mask_graphics_10,x:103.3899,y:42.719}).wait(1).to({graphics:mask_graphics_11,x:89.668,y:42.719}).wait(1).to({graphics:mask_graphics_12,x:89.668,y:55.8278}).wait(1).to({graphics:mask_graphics_13,x:89.668,y:55.8278}).wait(1).to({graphics:mask_graphics_14,x:89.668,y:55.8278}).wait(1).to({graphics:mask_graphics_15,x:89.668,y:55.8278}).wait(1).to({graphics:mask_graphics_16,x:89.668,y:55.8278}).wait(1).to({graphics:mask_graphics_17,x:89.668,y:56.2706}).wait(1).to({graphics:mask_graphics_18,x:89.668,y:56.2706}).wait(1).to({graphics:mask_graphics_19,x:89.668,y:69.124}).wait(1).to({graphics:mask_graphics_20,x:89.668,y:70.7033}).wait(1).to({graphics:mask_graphics_21,x:89.668,y:71.4728}).wait(1).to({graphics:mask_graphics_22,x:89.668,y:71.4728}).wait(1).to({graphics:mask_graphics_23,x:89.668,y:71.4728}).wait(1).to({graphics:mask_graphics_24,x:89.668,y:82.8251}).wait(1).to({graphics:mask_graphics_25,x:89.668,y:85.1615}).wait(1).to({graphics:mask_graphics_26,x:89.668,y:85.1615}).wait(1).to({graphics:mask_graphics_27,x:89.668,y:85.1615}).wait(1).to({graphics:mask_graphics_28,x:89.668,y:85.1615}).wait(1).to({graphics:mask_graphics_29,x:89.668,y:88.5651}).wait(1).to({graphics:mask_graphics_30,x:89.668,y:88.5651}).wait(1).to({graphics:mask_graphics_31,x:89.668,y:88.5651}).wait(1).to({graphics:mask_graphics_32,x:89.668,y:100.5444}).wait(1).to({graphics:mask_graphics_33,x:89.668,y:100.5444}).wait(1).to({graphics:mask_graphics_34,x:89.668,y:101.2186}).wait(1).to({graphics:mask_graphics_35,x:89.668,y:101.2186}).wait(1).to({graphics:mask_graphics_36,x:89.668,y:101.7283}).wait(1).to({graphics:mask_graphics_37,x:89.668,y:101.7283}).wait(1).to({graphics:mask_graphics_38,x:89.668,y:101.7283}).wait(189));

	// FlashAICB
	this.instance_5 = new lib.txtara();
	this.instance_5.parent = this;
	this.instance_5.setTransform(89.15,103.5);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(4).to({_off:false},0).wait(81).to({alpha:0},10).wait(132));

	// Layer_1
	this.instance_6 = new lib._160x600_img();
	this.instance_6.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(227));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.2,300,285.5,300);
// library properties:
lib.properties = {
	id: 'FF7FE0B90139445187E2309398A10FC3',
	width: 160,
	height: 600,
	fps: 18,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/160x600_ara_atlas_.png?1581504088321", id:"160x600_ara_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['FF7FE0B90139445187E2309398A10FC3'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;